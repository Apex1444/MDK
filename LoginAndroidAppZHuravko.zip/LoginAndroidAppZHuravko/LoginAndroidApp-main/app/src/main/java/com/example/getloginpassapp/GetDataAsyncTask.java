package com.example.getloginpassapp;

import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class GetDataAsyncTask extends AsyncTask<String, Void, String> {
    public AsyncResponse delegate;
    // Определение интерфейса AsyncResponse с методом processFinish, который принимает аргумент String
    public GetDataAsyncTask(AsyncResponse delegate) {
        this.delegate = delegate;
    }

    public interface AsyncResponse {
        void processFinish(String output);
    }
    // Этот метод вызывается при выполнении AsyncTask, он получает данные логина, пароля и URL, подключается к URL и извлекает полное имя
    @Override
    protected String doInBackground(String... strings) {
        try {
            String login = strings[0];
            String password = strings[1];
            String url_link = strings[2];
            // Кодируем данные логина и пароля с использованием кодировки UTF-8
            String data = URLEncoder.encode("login", "UTF-8") + "=" + URLEncoder.encode(login, "UTF-8");
            data += "&" + URLEncoder.encode("password", "UTF-8") + "=" + URLEncoder.encode(password, "UTF-8");
            // Создание объекта URL и открытие соединения с ним
            URL url = new URL(url_link);
            URLConnection connection = url.openConnection();
            connection.setDoOutput(true);
            // Запись закодированных данных в выходной поток соединения с помощью OutputStreamWriter
            OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
            writer.write(data);
            writer.flush();
            // Чтение данных из входного потока соединения с помощью BufferedReader
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));

            StringBuilder stringBuilder = new StringBuilder();
            String line = null;
            // Чтение каждой строки данных и добавление ее в StringBuilder
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                break;
            }
            // Возврат данных в виде строки
            return stringBuilder.toString();
        }
        catch (Exception e) {
            e.printStackTrace();
            return "Exception: " + e.getMessage();
        }
    }
    // Этот метод вызывается после завершения метода doInBackground, он передает полученные данные в метод processFinish интерфейса AsyncResponse
    @Override
    protected void onPostExecute(String result) {
        if (result != null && !result.equals("")) {
            delegate.processFinish(result);
        }
    }
}
